import java.util.ArrayList;
import java.util.Scanner;

public class ControleEstoque {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ArrayList<Produto> produtos = new ArrayList<>();

    public static void main(String[] args) {
        int opcao;

        do {
            exibirMenu();
            opcao = lerInteiro("Escolha uma opção: ");

            switch (opcao) {
                case 1:
                    cadastrarProduto();
                    break;
                case 2:
                    listarProdutos();
                    break;
                case 3:
                    buscarProduto();
                    break;
                case 4:
                    registrarVenda();
                    break;
                case 5:
                    exibirValorTotalEstoque();
                    break;
                case 6:
                    System.out.println("Sistema encerrado. Até logo!");
                    break;
                default:
                    System.out.println("Opção inválida. Escolha uma opção de 1 a 6.");
            }
            System.out.println();
        } while (opcao != 6);

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("==================================");
        System.out.println("     CONTROLE DE ESTOQUE - CANTINA");
        System.out.println("==================================");
        System.out.println("1 - Cadastrar produto");
        System.out.println("2 - Listar todos os produtos");
        System.out.println("3 - Buscar produto pelo código");
        System.out.println("4 - Registrar venda");
        System.out.println("5 - Exibir valor total do estoque");
        System.out.println("6 - Sair");
    }

    private static void cadastrarProduto() {
        System.out.println("--- Cadastro de produto ---");
        int codigo = lerInteiro("Código: ");

        if (buscarPorCodigo(codigo) != null) {
            System.out.println("Erro: já existe um produto com esse código.");
            return;
        }

        String nome;
        do {
            System.out.print("Nome: ");
            nome = scanner.nextLine().trim();
            if (nome.isEmpty()) {
                System.out.println("Erro: o nome não pode ficar vazio.");
            }
        } while (nome.isEmpty());

        double preco;
        do {
            preco = lerDouble("Preço unitário (R$): ");
            if (preco <= 0) {
                System.out.println("Erro: o preço deve ser maior que zero.");
            }
        } while (preco <= 0);

        int quantidade;
        do {
            quantidade = lerInteiro("Quantidade em estoque: ");
            if (quantidade < 0) {
                System.out.println("Erro: a quantidade não pode ser negativa.");
            }
        } while (quantidade < 0);

        produtos.add(new Produto(codigo, nome, preco, quantidade));
        System.out.println("Produto cadastrado com sucesso!");
    }

    private static void listarProdutos() {
        System.out.println("--- Produtos cadastrados ---");
        if (produtos.isEmpty()) {
            System.out.println("Não há produtos cadastrados.");
            return;
        }

        for (Produto produto : produtos) {
            produto.exibirDados();
        }
    }

    private static void buscarProduto() {
        System.out.println("--- Buscar produto ---");
        int codigo = lerInteiro("Informe o código: ");
        Produto produto = buscarPorCodigo(codigo);

        if (produto == null) {
            System.out.println("Produto não encontrado.");
        } else {
            produto.exibirDados();
        }
    }

    private static void registrarVenda() {
        System.out.println("--- Registrar venda ---");
        int codigo = lerInteiro("Código do produto: ");
        Produto produto = buscarPorCodigo(codigo);

        if (produto == null) {
            System.out.println("Produto não encontrado. A venda não foi realizada.");
            return;
        }

        int quantidadeVendida = lerInteiro("Quantidade vendida: ");

        if (quantidadeVendida <= 0) {
            System.out.println("Venda recusada: a quantidade deve ser maior que zero.");
            return;
        }

        if (quantidadeVendida > produto.getQuantidadeEstoque()) {
            System.out.println("Venda recusada: quantidade maior que o estoque disponível.");
            return;
        }

        produto.retirarEstoque(quantidadeVendida);
        System.out.println("Venda registrada com sucesso!");
        System.out.println("Quantidade restante: " + produto.getQuantidadeEstoque());
    }

    private static void exibirValorTotalEstoque() {
        double valorTotal = 0;

        for (Produto produto : produtos) {
            valorTotal += produto.calcularValorEmEstoque();
        }

        System.out.printf("Valor total do estoque: R$ %.2f%n", valorTotal);
    }

    private static Produto buscarPorCodigo(int codigo) {
        for (Produto produto : produtos) {
            if (produto.getCodigo() == codigo) {
                return produto;
            }
        }
        return null;
    }

    private static int lerInteiro(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Digite um número inteiro.");
            }
        }
    }

    private static double lerDouble(String mensagem) {
        while (true) {
            System.out.print(mensagem);
            try {
                String valor = scanner.nextLine().trim().replace(",", ".");
                return Double.parseDouble(valor);
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida. Digite um valor numérico.");
            }
        }
    }
}
