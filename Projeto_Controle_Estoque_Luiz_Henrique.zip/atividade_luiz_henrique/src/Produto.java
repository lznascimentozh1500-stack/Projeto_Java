public class Produto {
    private int codigo;
    private String nome;
    private double precoUnitario;
    private int quantidadeEstoque;

    public Produto(int codigo, String nome, double precoUnitario, int quantidadeEstoque) {
        this.codigo = codigo;
        this.nome = nome;
        this.precoUnitario = precoUnitario;
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void retirarEstoque(int quantidade) {
        quantidadeEstoque -= quantidade;
    }

    public double calcularValorEmEstoque() {
        return precoUnitario * quantidadeEstoque;
    }

    public void exibirDados() {
        System.out.printf("Código: %d | Produto: %s | Preço: R$ %.2f | Quantidade: %d%n",
                codigo, nome, precoUnitario, quantidadeEstoque);
    }
}
