# Controle de Estoque da Cantina

**Aluno:** Luiz Henrique  
**Turma:** não informada  
**Tema:** Opção A — Controle de Estoque da Cantina

## Descrição
Sistema de console desenvolvido em Java para cadastrar produtos da cantina, consultar registros, registrar vendas e calcular o valor total dos produtos disponíveis em estoque.

## Requisitos
- Java JDK 17 ou superior (ou versão compatível com os recursos utilizados).
- IntelliJ IDEA ou outra IDE Java.
- Não utiliza banco de dados nem bibliotecas externas.

## Como executar no IntelliJ IDEA
1. Abra o IntelliJ IDEA e crie/abra um projeto Java.
2. Coloque `ControleEstoque.java` e `Produto.java` dentro da pasta de código-fonte (`src`).
3. Confira se o JDK está configurado no projeto.
4. Abra `ControleEstoque.java` e execute o método `main`.
5. Utilize o menu exibido no console.

Também é possível compilar pelo terminal, dentro da pasta `src`:
```bash
javac Produto.java ControleEstoque.java
java ControleEstoque
```

## Funcionalidades
1. Cadastrar produto com código, nome, preço e quantidade.
2. Listar todos os produtos.
3. Buscar produto pelo código.
4. Registrar venda, reduzindo o estoque.
5. Calcular o valor total do estoque (preço unitário × quantidade de cada produto).
6. Encerrar o programa.

## Validações
- Bloqueia códigos repetidos.
- Não aceita nome vazio.
- Exige preço maior que zero.
- Não aceita quantidade inicial negativa.
- Exige quantidade vendida maior que zero.
- Impede venda acima do estoque disponível.
- Informa quando um código não existe.
- Uma venda recusada não altera a quantidade em estoque.
- Trata entradas que não sejam números nos campos numéricos.

## Registro dos testes
Consulte `TESTES.md` para as ações, dados utilizados, resultados esperados e resultados observados na validação manual.

## Organização
- `src/Produto.java`: classe que representa um produto.
- `src/ControleEstoque.java`: menu e operações do sistema.
- `TESTES.md`: roteiro e registro dos testes.

## Uso de inteligência artificial
Foi utilizada uma ferramenta de inteligência artificial como apoio à organização da solução, elaboração inicial do código e documentação. O aluno deve revisar, executar, compreender e ser capaz de explicar todas as partes do projeto.

## Limitações
Os dados ficam armazenados apenas na memória durante a execução. Ao fechar o programa, os produtos cadastrados são perdidos. Não há banco de dados, gravação em arquivos ou interface gráfica.
