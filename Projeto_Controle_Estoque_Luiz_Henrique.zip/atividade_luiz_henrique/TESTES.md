# Registro de testes — Controle de Estoque da Cantina

Os testes abaixo compõem o roteiro de verificação do sistema. Execute cada cenário no console e confira os resultados. O campo “resultado obtido” deve ser confirmado pelo aluno na execução final antes da entrega.

| Nº | Ação e dados utilizados | Resultado esperado | Resultado obtido |
|---|---|---|---|
| 1 | Cadastrar código 101, nome Suco, preço 5,00 e quantidade 10; depois listar. | Cadastro aceito e produto exibido com os dados informados. | A confirmar na execução pelo aluno. |
| 2 | Cadastrar novamente o código 101. | Cadastro bloqueado por código repetido. | A confirmar na execução pelo aluno. |
| 3 | Tentar cadastrar nome vazio, preço 0 ou quantidade -1. | Nome vazio recusado; preço solicita novo valor; quantidade negativa solicita novo valor. | A confirmar na execução pelo aluno. |
| 4 | Buscar o código 101. | Dados do Suco exibidos. | A confirmar na execução pelo aluno. |
| 5 | Buscar o código 999, não cadastrado. | Mensagem “Produto não encontrado”. | A confirmar na execução pelo aluno. |
| 6 | Vender 3 unidades do produto 101, que possui 10. | Venda aceita; estoque passa a 7 unidades. | A confirmar na execução pelo aluno. |
| 7 | Tentar vender 8 unidades quando restam 7; depois consultar o produto. | Venda recusada e estoque permanece em 7 unidades. | A confirmar na execução pelo aluno. |
| 8 | Iniciar o sistema sem cadastrar produtos e escolher listar. | Mensagem informando que não há produtos cadastrados. | A confirmar na execução pelo aluno. |
| 9 | Digitar a opção 9 no menu. | Mensagem de opção inválida e menu apresentado novamente. | A confirmar na execução pelo aluno. |

## Conferência do cálculo do estoque
Com 7 unidades do Suco a R$ 5,00 cada, o valor total esperado é **R$ 35,00**. Se houver outros produtos cadastrados, o sistema soma o valor de todos eles.
